<?php
echo exec('whoami');
?>